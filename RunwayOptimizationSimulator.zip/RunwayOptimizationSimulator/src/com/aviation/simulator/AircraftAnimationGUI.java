package com.aviation.simulator;

import javax.swing.*;
import java.awt.*;

public class AircraftAnimationGUI extends JFrame {

    private int planeX = -60;  // starting x-position
    private Timer timer;

    public AircraftAnimationGUI() {
        setTitle("Aircraft Takeoff Simulation");
        setSize(800, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Panel with custom painting
        JPanel animationPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                // Draw gray runway
                g.setColor(Color.GRAY);
                g.fillRect(0, 120, getWidth(), 60);

                // Draw white dashed center line
                g.setColor(Color.WHITE);
                for (int i = 0; i < getWidth(); i += 40) {
                    g.fillRect(i, 147, 20, 6);  // dashes in center of runway
                }

                // Draw aircraft (represented as a red rectangle)
                g.setColor(Color.RED);
                g.fillRect(planeX, 130, 50, 30);
            }
        };

        add(animationPanel);
        setVisible(true);

        // Timer for animation
        timer = new Timer(20, e -> {
            planeX += 5;
            if (planeX > getWidth()) {
                planeX = -60; // reset to left
            }
            animationPanel.repaint();
        });

        timer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AircraftAnimationGUI());
    }
}

