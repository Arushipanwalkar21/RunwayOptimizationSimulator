package com.aviation.simulator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RunwaySimGUI extends JFrame {

    private JTextField windField;
    private JTextField timeField;
    private JComboBox<String> airportBox;
    private JTextArea resultArea;

    public RunwaySimGUI() {
        setTitle("Runway Optimization Simulator");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Top: Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Enter Flight Details"));

        airportBox = new JComboBox<>(new String[]{"Delhi", "Mumbai", "Vizag", "Port Blair", "Bengaluru"});
        windField = new JTextField();
        timeField = new JTextField();

        inputPanel.add(new JLabel("Select Airport:"));
        inputPanel.add(airportBox);

        inputPanel.add(new JLabel("Wind Direction (°):"));
        inputPanel.add(windField);

        inputPanel.add(new JLabel("Arrival Time (HH:MM):"));
        inputPanel.add(timeField);

        JButton submitBtn = new JButton("Suggest Runway");
        inputPanel.add(new JLabel()); // empty
        inputPanel.add(submitBtn);

        add(inputPanel, BorderLayout.NORTH);

        // Bottom: Result Area
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        add(new JScrollPane(resultArea), BorderLayout.CENTER);

        // Action Listener
        submitBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                suggestRunway();
            }
        });

        setVisible(true);
    }

    private void suggestRunway() {
        String airport = (String) airportBox.getSelectedItem();
        String windStr = windField.getText().trim();
        String time = timeField.getText().trim();

        try {
            int windDir = Integer.parseInt(windStr);
            String suggestion = getRunwaySuggestion(airport, windDir, time);
            resultArea.setText(suggestion);
        } catch (NumberFormatException ex) {
            resultArea.setText("❌ Invalid wind direction. Please enter degrees (0–360).");
        }
    }

    // Basic sample logic
    private String getRunwaySuggestion(String airport, int windDir, String time) {
        String heading = "";

        if (windDir >= 315 || windDir <= 45) {
            heading = "Runway 09 (East-facing)";
        } else if (windDir > 45 && windDir <= 135) {
            heading = "Runway 18 (South-facing)";
        } else if (windDir > 135 && windDir <= 225) {
            heading = "Runway 27 (West-facing)";
        } else {
            heading = "Runway 36 (North-facing)";
        }

        return "Airport: " + airport +
                "\nWind Direction: " + windDir + "°" +
                "\nArrival Time: " + time +
                "\n\n✅ Suggested Runway: " + heading;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RunwaySimGUI());
    }
}


