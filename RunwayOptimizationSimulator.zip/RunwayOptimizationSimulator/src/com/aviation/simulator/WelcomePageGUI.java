package com.aviation.simulator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class WelcomePageGUI extends JFrame {

    public WelcomePageGUI() {
        setTitle("Runway Optimization Simulator");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Logo Image
        ImageIcon logoIcon = new ImageIcon("images/logo.jpeg"); // Put logo.jpeg in images/
        JLabel logoLabel = new JLabel(logoIcon);
        logoLabel.setHorizontalAlignment(JLabel.CENTER);
        add(logoLabel, BorderLayout.CENTER);

        // Start Button
        JButton startButton = new JButton("Start Simulation");
        startButton.setFont(new Font("Arial", Font.BOLD, 20));
        startButton.addActionListener(e -> {
            dispose();
            new MapSimulationPageGUI();
        });

        JPanel southPanel = new JPanel();
        southPanel.add(startButton);
        add(southPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        new WelcomePageGUI();
    }
}

