package com.aviation.simulator;

import javax.swing.*;
import java.awt.*;

public class TitlePageGUI extends JFrame {

    public TitlePageGUI() {
        setTitle("Runway Optimization Simulator");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JLabel titleLabel = new JLabel("Runway Optimization Simulator", JLabel.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 36));
        titleLabel.setForeground(new Color(0, 102, 204));
        
        add(titleLabel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TitlePageGUI());
    }
}

